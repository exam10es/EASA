
<?php
declare(strict_types=1);
define('APP_NAME','Exam App');
define('APP_ENV','development');
define('BASE_URL','/exam-app/public');
define('DB_HOST','localhost');
define('DB_NAME','exam_db');
define('DB_USER','root');
define('DB_PASS','');
