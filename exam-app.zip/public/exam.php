
<?php
require_once __DIR__.'/../app/bootstrap.php';
$db=Database::connect();
$qs=$db->query("SELECT * FROM questions LIMIT 5")->fetchAll();
?>
<!doctype html><html lang="ar"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="assets/css/app.css"></head><body>
<div class="container">
<form class="card" method="post" action="submit.php">
<?php foreach($qs as $q): ?>
<p><?=e($q['question'])?></p>
<label><input type="radio" name="q<?=$q['id']?>" value="1"> <?=e($q['a'])?></label><br>
<label><input type="radio" name="q<?=$q['id']?>" value="2"> <?=e($q['b'])?></label><br>
<?php endforeach; ?>
<button>إرسال</button>
</form></div></body></html>
