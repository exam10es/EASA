
<?php require_once __DIR__.'/../app/bootstrap.php'; ?>
<!doctype html><html lang="ar"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=APP_NAME?></title>
<link rel="stylesheet" href="assets/css/app.css">
</head><body>
<div class="container">
  <div class="card">
    <h2>اختبار تجريبي</h2>
    <a href="exam.php"><button>ابدأ</button></a>
  </div>
</div>
</body></html>
