
<?php require_once __DIR__.'/../app/bootstrap.php'; ?>
<!doctype html><html lang="ar"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="assets/css/app.css"></head><body>
<div class="container"><div class="card"><h3>تم الإرسال</h3></div></div>
</body></html>
