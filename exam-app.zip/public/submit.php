
<?php
require_once __DIR__.'/../app/bootstrap.php';
// Simple demo submit
redirect('/results.php');
