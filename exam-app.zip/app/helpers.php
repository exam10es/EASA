
<?php
function e(string $v): string { return htmlspecialchars($v,ENT_QUOTES,'UTF-8'); }
function redirect(string $p): never { header('Location: '.BASE_URL.$p); exit; }
