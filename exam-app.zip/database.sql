
CREATE TABLE questions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 question VARCHAR(255),
 a VARCHAR(255),
 b VARCHAR(255)
);
INSERT INTO questions(question,a,b) VALUES
('2+2=?','3','4');
