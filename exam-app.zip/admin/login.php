
<?php require_once __DIR__.'/../app/bootstrap.php';
if($_POST){
  $_SESSION['admin']=true;
  header('Location: dashboard.php'); exit;
}
?>
<!doctype html><html><body>
<form method="post"><button>Login Admin</button></form>
</body></html>
