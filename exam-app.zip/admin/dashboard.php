
<?php require_once __DIR__.'/../app/bootstrap.php';
if(empty($_SESSION['admin'])){ header('Location: login.php'); exit; }
?>
<!doctype html><html><body>
<h2>Admin Dashboard</h2>
<p>إدارة الأسئلة</p>
<a href="logout.php">خروج</a>
</body></html>
